(() => {
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('#main-nav');
  if (toggle && nav) toggle.addEventListener('click', () => { const open = toggle.getAttribute('aria-expanded') === 'true'; toggle.setAttribute('aria-expanded', String(!open)); nav.classList.toggle('is-open', !open); });
  const search = document.querySelector('#story-search');
  const filter = document.querySelector('#category-filter');
  const grid = document.querySelector('#story-grid');
  const noResults = document.querySelector('#no-results');
  function updateStories(){ if(!grid) return; const q=(search?.value||'').trim().toLowerCase(); const cat=filter?.value||'all'; let visible=0; grid.querySelectorAll('.story-card').forEach(card=>{const category=card.dataset.category||''; const matchesCategory=cat==='all'||category===cat; const matchesText=card.textContent.toLowerCase().includes(q); const show=matchesCategory&&matchesText; card.hidden=!show;if(show)visible++;}); if(noResults) noResults.hidden=visible>0; }
  search?.addEventListener('input',updateStories); filter?.addEventListener('change',updateStories);
  document.querySelector('#newsletter-form')?.addEventListener('submit', e => { e.preventDefault(); const msg=document.querySelector('#newsletter-message'); if(msg) msg.textContent='Thanks for your interest. Newsletter signups are not active yet; choose a provider in the site settings before launch.'; });
})();
